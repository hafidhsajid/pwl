<div class="container">
    <div class="row">
        <div class="col">
            <h1>Hello, <?php echo $name ?>!</h1>
        </div>
    </div>
</div>